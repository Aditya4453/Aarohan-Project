# Attendance Frontend

This is the frontend generated from the user's Frontend-Guide.md. Start with:

```
npm install
npm run dev
```
